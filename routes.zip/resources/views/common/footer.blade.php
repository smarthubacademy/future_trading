</div></div><footer class="text-center text-white" style="background-color:black">
    <div class="container p-4 pb-2">
       <section>
          <a class="btn text-white btn-floating m-2" href="{{ route('home')}}" role="button">
             Home
          </a>
          <a class="btn text-white btn-floating m-2" href="#!" role="button">
             Stock
          </a>
          <a class="btn text-white btn-floating m-2" href="#!" role="button">
             Search
          </a>
          
          <a class="btn text-white btn-floating m-2" href="{{ route('contact')}}" role="button">
             Inquiry
          </a>
          <a class="btn text-white btn-floating m-2" href="#!" role="button">
             Company Profile
          </a>
          <a class="btn text-white btn-floating m-2" href="#!" role="button">
             Contact
          </a>
       </section>
       <div class="container text-center p-3 mb-5" style="background-color: rgba(0, 0, 0, 0.2);">
          Compyright SMG Motors
       </div>
    </div>
 </footer>
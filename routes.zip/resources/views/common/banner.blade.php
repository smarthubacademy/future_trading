<div class="container-fluid mt-2">
    <div class="row  gy-3 my-3">
       <div class="col-md-6">
          <div class="card item-card">
             <img src="/images/banners/car_banner_1.png" class=" img-fluid p-5" alt="...">
          </div>
       </div>
       <div class="col-md-6">
          <div class="card item-card">
             <img src="/images/banners/car_banner_2.png" class=" img-fluid p-5" alt="...">
          </div>
       </div>
    </div>
 </div>
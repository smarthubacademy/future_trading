<img src="/images/banners/main_banner_1.jpeg" class="img-fluid mx-auto d-block" alt="">
   <div class="container">
      <div class="row">
         <div class="col-md-12 text-center m-3">
            <h1>
               Find The Car You Want,
               <span>
                  <b>
                     Your Way
                  </b>
               </span>
            </h1>
         </div>
      </div>
   </div>
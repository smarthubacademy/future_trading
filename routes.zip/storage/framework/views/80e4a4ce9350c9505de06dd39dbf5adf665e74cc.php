
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
<?php echo $__env->make('common.advanced_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="container">  
    <!-- items card -->
   <div class="container mt-5">
      YOUR RESULT
      <?php $__currentLoopData = $search_list->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row gy-3 my-3 text-center">
         <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quick_search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
               <div class="card item-card">
                  <img src="upload/images/<?php echo e($quick_search->ChassisNo); ?>_1.jpg" class="card-img-top img-fluid" alt="...">
                  <div class="card-body">
                     <h4 class="card-title"><?php echo e($quick_search->VehicleName); ?></h4>
                     <p class="card-text"><?php echo e($quick_search->Model); ?>-<?php echo e($quick_search->YearModel); ?></p>
                     <hr class="mb-4">
                     <p class="card-text">From JPY<b><?php echo e($quick_search->TargetPrice); ?></b></p>
                  </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   </div>
     
   </div>

  <!-- banner -->
  <?php echo $__env->make('common.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vehicle.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\future_trading\resources\views/vehicle/search.blade.php ENDPATH**/ ?>
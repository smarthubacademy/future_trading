<div class="container">
      <div class="row">
         <div class="col-md-12 text-center m-3">
            <h1>
               Find The Car You Want,
               <span>
                  <b>
                     Your Way
                  </b>
               </span>
            </h1>
         </div>
      </div>
   </div>

   <div class="container">
      <form id="quick_seaach" action="/<?php echo e($action); ?>" method="post">
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
         <div class="row justify-content-between">

            <div class="col-md-2">
               <select id="TypeOfBody" name="TypeOfBody" class="form-select" aria-label="Default select example">
                  <option value="" selected>Type</option>
                  <?php $__currentLoopData = $advSearch['bodytypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($body->TypeOfBody); ?>" <?php if($keys['TypeOfBody'] == $body->TypeOfBody): ?> selected="selected" <?php endif; ?>><?php echo e($body->TypeOfBody); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>

            <div class="col-md-2">
               <select id="Maker" name="Maker" class="form-select" aria-label="Default select example">
               <option value="" selected>Maker</option>
                  <?php $__currentLoopData = $advSearch['makers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($maker->Maker); ?>" <?php if($keys['Maker'] == $maker->Maker): ?> selected="selected" <?php endif; ?>><?php echo e($maker->Maker); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>

            <div class="col-md-2">
               <select id="VehicleName" name="VehicleName" class="form-select" aria-label="Default select example">
               <option value="" selected>Name</option>
                  <?php $__currentLoopData = $advSearch['vehiclenames']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiclename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($vehiclename->VehicleName); ?>" <?php if($keys['VehicleName'] == $vehiclename->VehicleName): ?> selected="selected" <?php endif; ?>><?php echo e($vehiclename->VehicleName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>

            <div class="col-md-2">
            <select id="yearModelFrom" name="yearModelFrom" class="form-select" aria-label="Default select example">
               <option value="" selected>YearModel</option>
                  <?php $__currentLoopData = $advSearch['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelFrom'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
               <select id="yearModelTo" name="yearModelTo" class="form-select" aria-label="Default select example">
                  <option value="" selected>YearModel</option>
                     <?php $__currentLoopData = $advSearch['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelTo'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>

            <div class="col-md-2">
               <select id="cc" name="cc" class="form-select" aria-label="Default select example">
               <option value="">CC</option>
                  <?php $__currentLoopData = $advSearch['ccs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($cc->EngineCapacityInCC); ?>" <?php if($keys['cc'] == $cc->EngineCapacityInCC): ?> selected="selected" <?php endif; ?>><?php echo e($cc->EngineCapacityInCC); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
         </div>
         <div class="row justify-content-between btm-mg">
            <div class="col-md-2">
               <select id="LeftHand" name="LeftHand" class="form-select" aria-label="Default select example">
                  <option value="">STEERING</option>
                  <option value="1">LEFT HAND STEERING</option>
                  <option value="0">RIGHT HAND STEERING</option>
               </select>
            </div>
            <div class="col-md-2">
               <select id="4WD" name="4WD" class="form-select" aria-label="Default select example">
                  <option value="">DRIVE</option>
                  <option value="0">2WD</option>
                  <option value="1">4WD</option>
               </select>
            </div>
            <div class="col-md-2">
               <select id="mileagefrom" name="mileagefrom" class="form-select" aria-label="Default select example">
                  <option value="">MILEAGE FROM</option>
                  <?php $__currentLoopData = $advSearch['mileages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mileage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($mileage->mileage); ?>" <?php if($keys['mileagefrom'] == $mileage->mileage): ?> selected="selected" <?php endif; ?>><?php echo e($mileage->mileage); ?> km</option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
               <select id="mileageto" name="mileageto" class="form-select" aria-label="Default select example">
                  <option value="">MILEAGE TO</option>
                  <?php $__currentLoopData = $advSearch['mileages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mileage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($mileage->mileage); ?>" <?php if($keys['mileageto'] == $mileage->mileage): ?> selected="selected" <?php endif; ?>><?php echo e($mileage->mileage); ?> km</option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
               <select id="transmission" name="transmission" class="form-select" aria-label="Default select example">
                   <option value="">TRANSMISSION</option>
                  <option value="AUTO">AUTOMATIC</option>
                  <option value="MANUAL">MANUAL</option>
                  <option value="30000">SMOOTHER</option>
               </select>
            </div>
            <div class="col-md-2">
            <select id="fuel" name="fuel" class="form-select" aria-label="Default select example">
               <option value="">FUEL</option>
                  <?php $__currentLoopData = $advSearch['fuels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($fuel->fuel); ?>" <?php if($keys['fuel'] == $fuel->fuel): ?> selected="selected" <?php endif; ?>><?php echo e($fuel->fuel); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
         </div>
         <div class="row justify-content-between btm-mg">   
            <div class="col-md-2">
               <select id="color" name="color" class="form-select" aria-label="Default select example">
                   <option value="">COLOR</option>
                   <?php $__currentLoopData = $advSearch['colors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($color->color); ?>" <?php if($keys['color'] == $color->color): ?> selected="selected" <?php endif; ?>><?php echo e($color->color); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>

            <div class="col-md-10 check-box">
               OPTIONS:
               <input type="checkbox" name="ab" id="ab" value="1"> Air Bag
               <input type="checkbox" name="ac" id="ac" value="1"> Air Conditioner
               <input type="checkbox" name="aw" id="aw" value="1"> Alloy Wheels
               <input type="checkbox" name="navi" id="navigation" value="1"> Navigation
               <input type="checkbox" name="tv" id="tv" value="1"> TV
               <input type="checkbox" name="dvd" id="dvd" value="1"> DVD
               
               <input type="checkbox" name="ps" id="ps" value="1"> Power Steering
               <input type="checkbox" name="pw" id="pw" value="1"> Power Windows
               <input type="checkbox" name="hr" id="hr" value="1"> Hight Roof
               <input type="checkbox" name="rs" id="rs" value="1"> Rear Spoiler
               <input type="checkbox" name="sr" id="sr" value="1"> Sun Roof
               <input type="checkbox" name="leather_seat" id="leather_seat" value="1"> Leather Seat
               <input type="checkbox" name="grillguard" id="grillguard" value="1"> Grill Guard
               <input type="checkbox" name="hdeck" id="hdeck" value="1"> High Deck
            </div>
         </div> 
         <div class="row justify-content-between">  
            <div class="col-md-12 text-end">
               <button type="submit" class="btn btn-primary">
                  <i class="fa-solid fa-magnifying-glass"></i>
                  <?php echo e($action); ?>

               </button>
            </div>
       </div>
     </form>
  </div><?php /**PATH C:\laragon\www\future_trading\resources\views/common/advanced_search.blade.php ENDPATH**/ ?>
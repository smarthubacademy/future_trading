
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
   <?php echo $__env->make('common.calc_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-md-12">
    <div class="table-responsive">
   <table class="table table-striped">
   <thead>
    <tr>
      <th scope="col">Vehicle Name</th>
      <th scope="col">Maker</th>
      <th scope="col">Year Model</th>
      <th scope="col">Model</th>
      <th scope="col">Color</th>
      <th scope="col">Options</th>
      <th scope="col">Picture</th>
    </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $search_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
         $time = strtotime($list->YearModel);
         $y = date('Y/m', $time);
      ?>
    <tr>
      <td><?php echo e($list->VehicleName); ?></td>
      <td><?php echo e($list->Maker); ?></td>
      <td><?php echo e($y); ?></td>
      <td><?php echo e($list->Model); ?></td>
      <td><?php echo e($list->Color); ?></td>
      <td><?php echo e($list->Remarks); ?></td>
      <td>
      <img src="upload/images/<?php echo e($list->ChassisNo); ?>_1.jpg" alt="..." width = "100px" height="75px">
      </td>
      
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
</div>
  
  <!-- banner -->
  <?php echo $__env->make('common.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vehicle.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\future_trading\resources\views/vehicle/calculate.blade.php ENDPATH**/ ?>
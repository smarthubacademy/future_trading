<div class="container">
      <div class="row">
         <div class="col-md-12 text-center m-3">
            <h1>
               Find The Car You Want,
               <span>
                  <b>
                     Your Way
                  </b>
               </span>
            </h1>
         </div>
      </div>
   </div>

   <div class="container">
      <form id="quick_seaach" action="/<?php echo e($action); ?>" method="post">
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
         <div class="row justify-content-between">
            <div class="col-md-2">
               <select id="TypeOfBody" name="TypeOfBody" class="form-select" aria-label="Default select example">
                  <option value="" selected>Type</option>
                  <?php $__currentLoopData = $quickSearchs['bodytypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($body->TypeOfBody); ?>" <?php if($keys['TypeOfBody'] == $body->TypeOfBody): ?> selected="selected" <?php endif; ?>><?php echo e($body->TypeOfBody); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div> 
            <div class="col-md-2">
               <select id="Maker" name="Maker" class="form-select" aria-label="Default select example">
               <option value="" selected>Maker</option>
                  <?php $__currentLoopData = $quickSearchs['makers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($maker->Maker); ?>" <?php if($keys['Maker'] == $maker->Maker): ?> selected="selected" <?php endif; ?>><?php echo e($maker->Maker); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
               <select id="VehicleName" name="VehicleName" class="form-select" aria-label="Default select example">
               <option value="" selected>Name</option>
                  <?php $__currentLoopData = $quickSearchs['vehiclenames']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiclename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($vehiclename->VehicleName); ?>" <?php if($keys['VehicleName'] == $vehiclename->VehicleName): ?> selected="selected" <?php endif; ?>><?php echo e($vehiclename->VehicleName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
            <select id="yearModelFrom" name="yearModelFrom" class="form-select" aria-label="Default select example">
               <option value="" selected>YearModel</option>
                  <?php $__currentLoopData = $quickSearchs['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelFrom'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
            <select id="yearModelTo" name="yearModelTo" class="form-select" aria-label="Default select example">
               <option value="" selected>YearModel</option>
                  <?php $__currentLoopData = $quickSearchs['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelTo'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2">
               <select id="cc" name="cc" class="form-select" aria-label="Default select example">
                  <option value="">CC</option>
                  <?php $__currentLoopData = $quickSearchs['ccs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($cc->EngineCapacityInCC); ?>" <?php if($keys['cc'] == $cc->EngineCapacityInCC): ?> selected="selected" <?php endif; ?>><?php echo e($cc->EngineCapacityInCC); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
         </div>
         <div class="row justify-content-between btm-mg">
            
            
            <div class="col-md-2 show">
               <select id="country" name="country" class="form-select" aria-label="Default select example">
                  <option value="">COUNTRY</option>
                  <?php $__currentLoopData = $quickSearchs['countries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($country->CountryName); ?>" <?php if($keys['country'] == $country->CountryName): ?> selected="selected" <?php endif; ?>><?php echo e($country->CountryName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
               </select>
               <?php if(!empty($message)): ?> <p><?php echo e($message); ?></p> <?php endif; ?>
            </div>
            <div class="col-md-7"></div>
            <div class="col-md-2 d-flex align-items-center">
               <button type="submit" class="btn btn-primary">
                  <i class="fa-solid fa-magnifying-glass"></i>
                  <?php echo e($action); ?>

               </button>
            </div>
            <div class="col-md-1 d-flex align-items-center">
                  <?php $__currentLoopData = $quickSearchs['makers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <a href="/calculate?maker=<?php echo e($maker->Maker); ?>" class="btn btn-info" role="button"><?php echo e($maker->Maker); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
       </div>
     </form>
  </div><?php /**PATH C:\laragon\www\future_trading\resources\views/common/calc_search.blade.php ENDPATH**/ ?>
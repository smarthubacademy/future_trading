<html lang="en">
<head>
<link rel="stylesheet" href="/css/admin.css">
</head>


<body>
   <?php if(Session::has('fail')): ?>
    <p><?php echo e(Session::get('fail')); ?></p>
    <?php endif; ?>
<form action="<?php echo e(route('login-admin')); ?>" method="post">
   
    <?php echo csrf_field(); ?>
  <div class="imgcontainer">
    <img src="/images/banners/car_banner_2.png" alt="Admin Login" class="avatar">
  </div>

  <div class="container">
    <div>
        <input type="text" placeholder="Enter Email" value="<?php echo e(old('email')); ?>" name="email">
        <p class="red"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    </div>
    <div>
        <input type="password" placeholder="Enter Password" name="password">
        <p class="red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
    </div>
    <div>
        <button type="submit">Login</button>
    </div>
    <div>
        <label>
        Forgot <a href="#">password?</a>
        </label>
    </div>
  </div>
</form>
</body>
</html><?php /**PATH C:\laragon\www\future_trading\resources\views/admin/login.blade.php ENDPATH**/ ?>
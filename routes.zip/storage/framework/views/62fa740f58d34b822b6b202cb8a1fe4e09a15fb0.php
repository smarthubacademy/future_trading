<div class="container-fluid">
      <div class="row">
         <div class="col-md-12 text-center m-3">
            <h1>
               Find The Car You Want,
               <span>
                  <b>
                     Your Way
                  </b>
               </span>
            </h1>
         </div>
      </div>
   </div>

   <div class="container-fluid">
      <form id="quick_seaach" action="/<?php echo e($action); ?>" method="post">
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
         <div class="row justify-content-between">
            <div class="col-md-2 col_m">
               <select id="TypeOfBody" name="TypeOfBody" class="form-select" aria-label="Default select example">
                  <option value="" selected>Type</option>
                  <?php $__currentLoopData = $quickSearchs['bodytypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($body->TypeOfBody); ?>" <?php if($keys['TypeOfBody'] == $body->TypeOfBody): ?> selected="selected" <?php endif; ?>><?php echo e($body->TypeOfBody); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div> 
            <div class="col-md-2 col_m">
               <select id="Maker" name="Maker" class="form-select" aria-label="Default select example">
               <option value="" selected>Maker</option>
                  <?php $__currentLoopData = $quickSearchs['makers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($maker->Maker); ?>" <?php if($keys['Maker'] == $maker->Maker): ?> selected="selected" <?php endif; ?>><?php echo e($maker->Maker); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2 col_m">
               <select id="VehicleName" name="VehicleName" class="form-select" aria-label="Default select example">
               <option value="" selected>Name</option>
                  <?php $__currentLoopData = $quickSearchs['vehiclenames']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiclename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($vehiclename->VehicleName); ?>" <?php if($keys['VehicleName'] == $vehiclename->VehicleName): ?> selected="selected" <?php endif; ?>><?php echo e($vehiclename->VehicleName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2 col_m">
            <select id="yearModelFrom" name="yearModelFrom" class="form-select" aria-label="Default select example">
               <option value="" selected>YearModel</option>
                  <?php $__currentLoopData = $quickSearchs['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelFrom'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2 col_m">
            <select id="yearModelTo" name="yearModelTo" class="form-select" aria-label="Default select example">
               <option value="" selected>YearModel</option>
                  <?php $__currentLoopData = $quickSearchs['yearModels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($yearModel->YearModel); ?>" <?php if($keys['yearModelTo'] == $yearModel->YearModel): ?> selected="selected" <?php endif; ?>><?php echo e($yearModel->YearModel); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
            <div class="col-md-2 col_m">
               <select id="cc" name="cc" class="form-select" aria-label="Default select example">
                  <option value="">CC</option>
                  <?php $__currentLoopData = $quickSearchs['ccs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($cc->EngineCapacityInCC); ?>" <?php if($keys['cc'] == $cc->EngineCapacityInCC): ?> selected="selected" <?php endif; ?>><?php echo e($cc->EngineCapacityInCC); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
            </div>
           
            <div class="col-md-2 col_m2">
               <button type="submit" class="btn btn-primary search_u">
                  <i class="fa-solid fa-magnifying-glass"></i>
                  <?php echo e($action); ?>

               </button>
            </div>
       </div>
     </form>
  </div><?php /**PATH C:\laragon\www\future_trading\resources\views/common/quick_search.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <img src="/images/banners/main_banner_1.jpeg" class="img-fluid mx-auto d-block" alt="">
   <?php echo $__env->make('common.quick_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- items card -->
   <div class="container-fluid">
      NEW ARRIVAL
      <?php $__currentLoopData = $newArrivalList->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row gy-3 my-3 text-center">
         <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newArrival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
               <div class="card item-card">
                  <img src="upload/images/<?php echo e($newArrival->ChassisNo); ?>_1.jpg" class="card-img-top img-fluid" alt="...">
                  <div class="card-body">
                     <h4 class="card-title"><?php echo e($newArrival->VehicleName); ?></h4>
                     <p class="card-text"><?php echo e($newArrival->Model); ?>-<?php echo e($newArrival->YearModel); ?></p>
                     <hr class="mb-4">
                     <p class="card-text">From JPY<b><?php echo e($newArrival->TargetPrice); ?></b></p>
                  </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   </div>

   <div class="container-fluid mt-5">
      MOST AFFORDABLE
      <?php $__currentLoopData = $mostAffordableList->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row gy-3 my-3 text-center">
         <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostAffordable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
               <div class="card item-card">
                  <img src="upload/images/<?php echo e($newArrival->ChassisNo); ?>_1.jpg" class="card-img-top img-fluid" alt="...">
                  <div class="card-body">
                     <h4 class="card-title"><?php echo e($mostAffordable->VehicleName); ?></h4>
                     <p class="card-text"><?php echo e($mostAffordable->Model); ?>-<?php echo e($mostAffordable->YearModel); ?></p>
                     <hr class="mb-4">
                     <p class="card-text">From JPY<b><?php echo e($mostAffordable->TargetPrice); ?></b></p>
                  </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   </div>

   <div class="container-fluid">
      HIGH GRADE
      <?php $__currentLoopData = $highGradedList->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row gy-3 my-3 text-center">
         <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highGraded): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
               <div class="card item-card">
                  <img src="upload/images/<?php echo e($newArrival->ChassisNo); ?>_1.jpg" class="card-img-top img-fluid" alt="...">
                  <div class="card-body">
                     <h4 class="card-title"><?php echo e($highGraded->VehicleName); ?></h4>
                     <p class="card-text"><?php echo e($highGraded->Model); ?>-<?php echo e($highGraded->YearModel); ?></p>
                     <hr class="mb-4">
                     <p class="card-text">From JPY<b><?php echo e($mostAffordable->TargetPrice); ?></b></p>
                  </div>
               </div>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   </div>

  <!-- banner -->
  <?php echo $__env->make('common.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vehicle.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\future_trading\resources\views/vehicle/home.blade.php ENDPATH**/ ?>